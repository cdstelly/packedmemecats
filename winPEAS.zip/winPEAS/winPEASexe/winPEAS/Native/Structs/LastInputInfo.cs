﻿namespace winPEAS.Native.Structs
{
    internal struct LastInputInfo
    {
        public uint Size;
        public uint Time;
    }
}
