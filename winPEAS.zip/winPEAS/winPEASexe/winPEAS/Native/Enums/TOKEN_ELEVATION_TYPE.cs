﻿namespace winPEAS.Native.Enums
{
    public enum TOKEN_ELEVATION_TYPE
    {
        Default = 1,
        Full,
        Limited
    }
}
