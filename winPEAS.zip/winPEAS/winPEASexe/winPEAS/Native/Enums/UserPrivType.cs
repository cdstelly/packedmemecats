﻿namespace winPEAS.Native.Enums
{
    public enum UserPrivType
    {
        Guest = 0,
        User = 1,
        Administrator = 2
    }
}
